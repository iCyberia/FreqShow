#!/usr/bin/env python3
import pygame
from PIL import Image
from evdev import InputDevice, ecodes, list_devices
import select

import st7796_lcd as st7796
import controller
import model

DISPLAY_WIDTH = 480
DISPLAY_HEIGHT = 320

# Touch mapping tweaks
TOUCH_SWAP_XY = True
TOUCH_FLIP_X = False
TOUCH_FLIP_Y = True


def surface_to_pil(surface: pygame.Surface) -> Image.Image:
    """Convert a pygame surface into a PIL Image for the LCD driver."""
    raw = pygame.image.tostring(surface, "RGB")
    width, height = surface.get_size()
    image = Image.frombytes("RGB", (width, height), raw)
    image = image.transpose(Image.FLIP_LEFT_RIGHT)
    return image


def present_to_lcd(lcd, surface: pygame.Surface) -> None:
    """Push the pygame surface to the physical LCD."""
    lcd.show_image(surface_to_pil(surface))


def find_touch_device():
    return InputDevice("/dev/input/event0")

#
    """Find a touchscreen-like evdev device."""
    for path in list_devices():
        try:
            dev = InputDevice(path)
            caps = dev.capabilities()

            abs_caps = caps.get(ecodes.EV_ABS, [])
            key_caps = caps.get(ecodes.EV_KEY, [])

            abs_codes = {item[0] for item in abs_caps}
            key_codes = set(key_caps)

            has_touch_xy = (
                (ecodes.ABS_X in abs_codes and ecodes.ABS_Y in abs_codes)
                or
                (ecodes.ABS_MT_POSITION_X in abs_codes and ecodes.ABS_MT_POSITION_Y in abs_codes)
            )
            has_touch_key = ecodes.BTN_TOUCH in key_codes or ecodes.BTN_LEFT in key_codes

            if has_touch_xy and has_touch_key:
                return dev
        except Exception:
            pass
    return None


def get_touch_axes(dev):
    """Return axis codes and min/max values."""
    caps = dev.capabilities().get(ecodes.EV_ABS, [])
    abs_codes = {item[0] for item in caps}

    if ecodes.ABS_MT_POSITION_X in abs_codes and ecodes.ABS_MT_POSITION_Y in abs_codes:
        x_code = ecodes.ABS_MT_POSITION_X
        y_code = ecodes.ABS_MT_POSITION_Y
    else:
        x_code = ecodes.ABS_X
        y_code = ecodes.ABS_Y

    try:
        x_info = dev.absinfo(x_code)
        y_info = dev.absinfo(y_code)
        x_min, x_max = x_info.min, x_info.max
        y_min, y_max = y_info.min, y_info.max
    except Exception:
        x_min, x_max = 0, 4095
        y_min, y_max = 0, 4095

    return x_code, y_code, x_min, x_max, y_min, y_max


def map_touch(raw_x, raw_y, width, height, x_min, x_max, y_min, y_max):
    """Map raw touch coordinates to screen coordinates."""
    if TOUCH_SWAP_XY:
        x = int((raw_y - y_min) * (width - 1) / max(1, (y_max - y_min)))
        y = int((raw_x - x_min) * (height - 1) / max(1, (x_max - x_min)))
    else:
        x = int((raw_x - x_min) * (width - 1) / max(1, (x_max - x_min)))
        y = int((raw_y - y_min) * (height - 1) / max(1, (y_max - y_min)))

    if TOUCH_FLIP_X:
        x = (width - 1) - x
    if TOUCH_FLIP_Y:
        y = (height - 1) - y

    return x, y

def wait_for_touch_release_in_button(dev, button_rect, width, height):
    """Wait for a touch release and return True if it ended inside the button."""
    if dev is None:
        return False

    x_code, y_code, x_min, x_max, y_min, y_max = get_touch_axes(dev)

    raw_x = None
    raw_y = None

    while True:
        r, _, _ = select.select([dev.fd], [], [], None)
        if dev.fd not in r:
            continue

        for event in dev.read():
            if event.type == ecodes.EV_ABS:
                if event.code == x_code:
                    raw_x = event.value
                elif event.code == y_code:
                    raw_y = event.value

            elif event.type == ecodes.EV_KEY and event.code == ecodes.BTN_TOUCH:
                if event.value == 0 and raw_x is not None and raw_y is not None:
                    x, y = map_touch(raw_x, raw_y, width, height, x_min, x_max, y_min, y_max)
                    print(f"ERROR SCREEN TOUCH mapped=({x},{y}) button={button_rect}", flush=True)
                    return button_rect.collidepoint((x, y))


def draw_error_screen(screen: pygame.Surface, error_text: str) -> None:
    """Draw the SDR/startup error dialog."""
    screen.fill((20, 20, 20))

    width, height = screen.get_size()

    font_title = pygame.font.Font(None, 36)
    font_body = pygame.font.Font(None, 24)

    title = font_title.render("Startup Error", True, (255, 80, 80))
    title_rect = title.get_rect(center=(width // 2, height // 4))
    screen.blit(title, title_rect)

    lines = [
        "FreqShow hit an error during startup or runtime.",
        "",
        "Touch anywhere on the screen to try again.",
        "",
        f"Error: {error_text}",
    ]

    y = height // 4 + 40
    for line in lines:
        text = font_body.render(line, True, (230, 230, 230))
        text_rect = text.get_rect(center=(width // 2, y))
        screen.blit(text, text_rect)
        y += 28


def show_sdr_error(lcd, screen: pygame.Surface, error_text: str) -> bool:
    """Show the SDR error screen until the user touches anywhere to retry."""
    touch_dev = find_touch_device()

    while True:
        draw_error_screen(screen, error_text)
        pygame.display.flip()
        present_to_lcd(lcd, screen)

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                return False
            if event.type == pygame.KEYDOWN and event.key in (
                pygame.K_RETURN,
                pygame.K_SPACE,
                pygame.K_ESCAPE,
            ):
                return True
            if event.type == pygame.MOUSEBUTTONDOWN:
                return True

        if touch_dev is not None:
            x_code, y_code, x_min, x_max, y_min, y_max = get_touch_axes(touch_dev)

            raw_x = None
            raw_y = None

            r, _, _ = select.select([touch_dev.fd], [], [], 0.05)
            if touch_dev.fd in r:
                for event in touch_dev.read():
                    if event.type == ecodes.EV_ABS:
                        if event.code == x_code:
                            raw_x = event.value
                        elif event.code == y_code:
                            raw_y = event.value
                    elif event.type == ecodes.EV_KEY and event.code == ecodes.BTN_TOUCH:
                        if event.value == 0:
                            return True


def main() -> None:
    import traceback

    lcd = st7796.st7796()
    lcd.lcd_init()
    lcd.clear()

    pygame.init()
    screen = pygame.display.set_mode((DISPLAY_WIDTH, DISPLAY_HEIGHT))
    pygame.display.set_caption("FreqShow LCD")

    while True:
        try:
            width, height = screen.get_size()

            fsmodel = model.FreqShowModel(width, height)
            fscontroller = controller.FreqShowController(fsmodel)

            clock = pygame.time.Clock()
            running = True
            touch_dev = find_touch_device()

            while running:
                for event in pygame.event.get():
                    if event.type == pygame.QUIT:
                        running = False
                    elif event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE:
                        running = False

                if touch_dev is not None:
                    x_code, y_code, x_min, x_max, y_min, y_max = get_touch_axes(touch_dev)

                    raw_x = None
                    raw_y = None

                    r, _, _ = select.select([touch_dev.fd], [], [], 0.01)
                    if touch_dev.fd in r:
                        for event in touch_dev.read():
                            if event.type == ecodes.EV_ABS:
                                if event.code == x_code:
                                    raw_x = event.value
                                elif event.code == y_code:
                                    raw_y = event.value
                            elif event.type == ecodes.EV_KEY and event.code == ecodes.BTN_TOUCH:
                                if event.value == 0 and raw_x is not None and raw_y is not None:
                                    x, y = map_touch(
                                        raw_x, raw_y,
                                        screen.get_width(), screen.get_height(),
                                        x_min, x_max, y_min, y_max
                                    )
                                    if hasattr(fscontroller.current(), "click"):
                                        fscontroller.current().click((x, y))

                fscontroller.current().render(screen)
                pygame.display.flip()
                present_to_lcd(lcd, screen)
                clock.tick(30)

            try:
                fsmodel.cleanup()
            except Exception:
                pass

            break

        except Exception as e:
            print(f"FreqShow startup/runtime error: {e}", flush=True)
            traceback.print_exc()

            retry = show_sdr_error(lcd, screen, str(e))
            if not retry:
                break

    pygame.quit()


if __name__ == "__main__":
    main()
